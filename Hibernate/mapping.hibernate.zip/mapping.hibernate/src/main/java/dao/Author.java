package dao;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Author {
	
	public Author(int authorId, String name, List<Book> booklist) {
		super();
		this.authorId = authorId;
		this.name = name;
		this.booklist = booklist;
	}
	
	public Author() {};

	@Id
	 private int authorId;
	 private String name;

	//one author can have many books
	 @OneToMany(targetEntity = Book.class,cascade =CascadeType.ALL)
		
	 List<Book> booklist;

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Book> getBooklist() {
		return booklist;
	}

	public void setBooklist(List<Book> booklist) {
		this.booklist = booklist;
	}

	@Override
	public String toString() {
		return "Author [authorId=" + authorId + ", name=" + name + ", booklist=" + booklist + "]";
	}
}
