package dao;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;


@Entity 
public class DepartmentM {
 
	@Id
	int dCode;
	
	String dName;
	@OneToMany(targetEntity = EmployeeM.class,cascade =CascadeType.ALL,fetch =FetchType.LAZY)
	
	 List<EmployeeM> emplist;
	
	
	public DepartmentM()
	{
		
	}
	
 
 
	public DepartmentM(int dCode, String dName, List<EmployeeM> emplist) {
		super();
		this.dCode = dCode;
		this.dName = dName;
		this.emplist = emplist;
	}
 
 
 
	public int getdCode() {
		return dCode;
	}
 
 
	public void setdCode(int dCode) {
		this.dCode = dCode;
	}
 
 
	public String getdName() {
		return dName;
	}
 
 
	public void setdName(String dName) {
		this.dName = dName;
	}
 
 
	public List<EmployeeM> getEmplist() {
		return emplist;
	}
 
 
	public void setEmplist(List<EmployeeM> list) {
		this.emplist = list;
	}
 
 
	@Override
	public String toString() {
		return "Department [dCode=" + dCode + ", dName=" + dName + ", emplist=" + emplist + "]";
	}
	
	
	
	
	
	
	
}
 
