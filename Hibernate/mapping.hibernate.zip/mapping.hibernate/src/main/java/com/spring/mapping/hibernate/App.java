package com.spring.mapping.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import dao.Address;
import dao.Author;
import dao.Book;
import dao.DepartmentM;
import dao.Employee;
import dao.EmployeeM;
import dao.Student;

/**
 * Hello world!
 *
 */
public class App 
{
	public static void main(String args[]) {
		
// ------------------------------------- one to one both example's session factory ------------------------------------------
//	SessionFactory sessionFactory= new Configuration().
//			   configure("hiber.config.xml").
//			   addAnnotatedClass(Student.class).
//			   addAnnotatedClass(Address.class).
//			   addAnnotatedClass(Employee.class).
//			   buildSessionFactory();
//	   
//	      
//	          Session session =sessionFactory.openSession();
//	          
//	          Transaction txt =session.beginTransaction();
	          
// -------------------------------------- one to one 1st example --------------------------------------------------------------------	          
	          
	          
//	          Address a1= new Address();
//	          a1.setAddressid(1);
//	          a1.setCity("bombay");
//	          
//	          session.save(a1);
//	          
//	          Student s1 = new Student();
//	          s1.setRollno(101);
//	          s1.setName("Ajay");
//	          s1.setAddress(a1);
//	          session.save(s1);
	          
// -----------------------------------------one to one - 2nd example ------------------------------------------------------------------
//	          Address a2 =new Address();
//	          a2.setAddressid(2);
//	          a2.setCity("Chennai");
//	          
//	          
//	          Employee e1=new Employee();
//	          e1.setEmp_id(1);
//	          e1.setEmp_name("Krishna");
//	          e1.setSalary(70000);
//	          e1.setAddress(a2);
//	          session.save(e1);
//	          	        
//	          txt.commit();
	          
//---------------------------------------- one to many -1st example ------------------------------------------------------------------
	          
//		SessionFactory sessionFactory= new Configuration().
//				   configure("hiber.config.xml").
//				   addAnnotatedClass(EmployeeM.class).
//				   addAnnotatedClass(DepartmentM.class).
//				   buildSessionFactory();
//		
//		  Session session =sessionFactory.openSession();
//          Transaction txt =session.beginTransaction();
//
//           EmployeeM e1= new EmployeeM(101,"asha",3000.0);
//           EmployeeM e2= new EmployeeM(102,"jay",7000.0);
// 
//          
//          List<EmployeeM> list= new ArrayList();
//          list.add(e1);
//          list.add(e2);
//
//          DepartmentM ojbD= new DepartmentM();
//          ojbD.setdCode(1);
//          ojbD.setdName("Admin");
//          ojbD.setEmplist(list);
//
//          session.save(ojbD);
//          txt.commit();

// ----------------------------------------------- one to many - 2nd example --------------------------------------------------------- 	   
	   
//          SessionFactory sessionFactory= new Configuration().
//				   configure("hiber.config.xml").
//				   addAnnotatedClass(Book.class).
//				   addAnnotatedClass(Author.class).
//				   buildSessionFactory();
//		
//		  Session session =sessionFactory.openSession();
//         Transaction txt =session.beginTransaction();
//
//          Book b1= new Book(1,"Meluha");
//          Book b2= new Book(2,"Key");
//
//         
//         List<Book> list= new ArrayList();
//         list.add(b1);
//         list.add(b2);
//
//         Author ojbA= new Author();
//         ojbA.setAuthorId(101);
//         ojbA.setName("Amish");
//         ojbA.setBooklist(list);
//
//         session.save(ojbA);
//         txt.commit();
	   
// ------------------------------------ lazy loading ---------------------------------------------------------
         
         SessionFactory sessionFactory= new Configuration().
      		   configure("hiber.config.xml").
      		   addAnnotatedClass(EmployeeM.class).
      		   addAnnotatedClass(DepartmentM.class).
      		   buildSessionFactory();

                Session session =sessionFactory.openSession();


                DepartmentM  d= session.get(DepartmentM.class, 1);

            System.out.print( d.getdName());
           // System.out.print(d.getEmplist());
       
                

	 
	    }
}

///summary:

// 1) address-> student(one to one relationship)

// 2)address -> employee(one to one example-2) ,(using caascadeType, 
//to establish the connection b/w fk and pk automatically,
//instead of we explicily doing it with the session.save(a1);)

//3)department -> employee (one to many example -1)

//4) author -> book (one to many example - 2)

